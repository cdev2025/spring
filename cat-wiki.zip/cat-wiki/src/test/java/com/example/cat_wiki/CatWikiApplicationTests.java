package com.example.cat_wiki;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CatWikiApplicationTests {

	@Test
	void contextLoads() {
	}

}
