package com.example.cat_wiki;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CatWikiApplication {

	public static void main(String[] args) {
		SpringApplication.run(CatWikiApplication.class, args);
	}

}
