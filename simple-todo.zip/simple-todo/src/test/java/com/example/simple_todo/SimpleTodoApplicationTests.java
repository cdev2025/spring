package com.example.simple_todo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimpleTodoApplicationTests {

	@Test
	void contextLoads() {
	}

}
