package com.example.simple_todo_api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimpleTodoApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SimpleTodoApiApplication.class, args);
	}

}
