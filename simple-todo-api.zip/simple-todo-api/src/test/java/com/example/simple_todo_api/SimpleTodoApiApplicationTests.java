package com.example.simple_todo_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimpleTodoApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
