package com.example.readingnoteapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReadingNoteApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
