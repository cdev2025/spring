package com.example.mysqltest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MysqltestApplicationTests {

	@Test
	void contextLoads() {
	}

}
